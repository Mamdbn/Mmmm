
const debtorAccounts = JSON.parse(localStorage.getItem('debtorAccounts')) || {};
let userEmail = localStorage.getItem('userEmail');
let userPassword = localStorage.getItem('userPassword');

function login() {
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;

    // تحقق من البريد الإلكتروني وكلمة المرور
    if (email === userEmail && password === userPassword) {
        alert("تم تسجيل الدخول بنجاح!");
        showApp();
    } else {
        alert("البريد الإلكتروني أو كلمة المرور خاطئة.");
    }
}

function register() {
    // طلب البريد الإلكتروني وكلمة مرور جديدة
    userEmail = prompt("أدخل بريدك الإلكتروني:");
    userPassword = prompt("أدخل كلمة مرورك:");

    // تخزين البريد الإلكتروني وكلمة المرور
    localStorage.setItem('userEmail', userEmail);
    localStorage.setItem('userPassword', userPassword);
    alert("تم تسجيل حسابك بنجاح! يمكنك الآن تسجيل الدخول.");
    showApp();
}

function showApp() {
    document.getElementById('app').style.display = 'block';
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('paymentForm').style.display = 'block'; // إظهار نموذج التسديد
}

function initializeApp() {
    if (!userEmail || !userPassword) {
        register();
    }
}

initializeApp();

document.getElementById('loginButton').addEventListener('click', function() {
    login();
});

document.getElementById('debtForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const debtorName = document.getElementById('debtorName').value;
    const debtName = document.getElementById('debtName').value;
    const debtAmount = parseFloat(document.getElementById('debtAmount').value);

    if (!debtorAccounts[debtorName]) {
        debtorAccounts[debtorName] = { totalDebt: 0, debts: [] };
    }
    debtorAccounts[debtorName].totalDebt += debtAmount;
    debtorAccounts[debtorName].debts.push({ name: debtName, amount: debtAmount });

    localStorage.setItem('debtorAccounts', JSON.stringify(debtorAccounts));
    document.getElementById('debtForm').reset();
});

document.getElementById('paymentForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const debtorName = document.getElementById('paymentDebtorName').value;
    const paymentAmount = parseFloat(document.getElementById('paymentAmount').value);

    if (debtorAccounts[debtorName] && debtorAccounts[debtorName].totalDebt >= paymentAmount) {
        debtorAccounts[debtorName].totalDebt -= paymentAmount;
        alert(`تم تسديد ${paymentAmount} ريال من دين ${debtorName}.`);
        localStorage.setItem('debtorAccounts', JSON.stringify(debtorAccounts));
        document.getElementById('paymentForm').reset();
    } else {
        alert("المبلغ المدفوع أكبر من الدين أو ليس هناك دين للمدين.");
    }
});

function updateDebtorDetails(debtorName) {
    const debtorDetails = document.getElementById('debtorDetails');
    debtorDetails.innerHTML = '';

    if (debtorAccounts[debtorName]) {
        const detailsHeader = document.createElement('h3');
        detailsHeader.textContent = `إجمالي الدين: ${debtorAccounts[debtorName].totalDebt} ريال`;
        debtorDetails.appendChild(detailsHeader);

        const detailsList = document.createElement('ul');
        debtorAccounts[debtorName].debts.forEach(debt => {
            const detailItem = document.createElement('li');
            detailItem.innerHTML = `
                ${debt.name}: ${debt.amount} ريال 
                <button class="delete" data-debt-name="${debt.name}">حذف</button>
            `;
            detailsList.appendChild(detailItem);

            detailItem.querySelector('.delete').addEventListener('click', function() {
                removeDebtFromAccount(debtorName, debt.name, debt.amount);
                updateDebtorDetails(debtorName);
            });
        });
        debtorDetails.appendChild(detailsList);
    }
}

document.getElementById('searchButton').addEventListener('click', function() {
    const searchName = document.getElementById('searchDebtor').value;
    const debtorAccountsList = document.getElementById('debtorAccounts');

    debtorAccountsList.innerHTML = '';
    if (debtorAccounts[searchName]) {
        const listItem = document.createElement('li');
        listItem.textContent = `${searchName}: إجمالي الدين ${debtorAccounts[searchName].totalDebt} ريال`;
        debtorAccountsList.appendChild(listItem);
        updateDebtorDetails(searchName);
    } else {
        alert('لا توجد حسابات بهذا الاسم.');
    }
});

function removeDebtFromAccount(debtorName, debtName, debtAmount) {
    if (debtorAccounts[debtorName]) {
        debtorAccounts[debtorName].debts = debtorAccounts[debtorName].debts.filter(debt => debt.name !== debtName);
        debtorAccounts[debtorName].totalDebt -= debtAmount;
        localStorage.setItem('debtorAccounts', JSON.stringify(debtorAccounts));
    }
}

document.getElementById('backupButton').addEventListener('click', function() {
    alert(`تم النسخ الاحتياطي للديون إلى البريد الإلكتروني: ${userEmail}`);
});

document.getElementById('restoreButton').addEventListener('click', function() {
    const email = prompt("أدخل بريدك الإلكتروني لاسترجاع البيانات:");
    if (email) {
        alert(`تم استرجاع البيانات من البريد الإلكتروني: ${email}`);
        localStorage.setItem('debtorAccounts', JSON.stringify(debtorAccounts));
    }
});
